#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

//function in question
double f(double x){
	return cos(2*x) + sin(3*x);
}

//main numerical computation method
void bisection( int one, int two, double threshold, int errorType, double *root, int *count, bool *flag){;
	//interval and iteration definition
    double x1 = one;
	double x2 = two;
	double x3;
	double x4;
	int iteration = -1;
	double error = 1;
	
	//deals with improper intervals
	if(f(x1) * f(x2) >= 0){
		cout<<"The given parameters, x1 and x2, are incorrectly chosen. Terminating...";
	}else{
	    while(f(x1) * f(x2) < 0){
	        x3 = (x1+x2)/2;
	        iteration++;
	        //check for root
	        if(f(x3) == 0){
	           cout<<"The root is " << x3;
	           break;
	        } else if(f(x1)*f(x3) < 0){
	            x2 = x3;
	            x4 = x1;
	        }else{
	            x1 = x3;
	            x4 = x2;
	        }
	        //branch for error type
	        if((errorType == 1)){
	            if(error < threshold){
                    cout<<"Iteration: " << iteration << " and the root estimated is: " << setprecision(9) << x3;
                    *root = x3;
                    *count = iteration;
                    *flag = true;
	                break;
	            }
	            cout<<"Iteration: " << iteration<< " and the root estimated is: " << setprecision(9) << x3 <<"\n";
	            error = abs(x4-x3);
	        }else if(errorType == 2){
	            if(error < threshold){
                    cout<<"Iteration: " << iteration << " and the root estimated is: " << setprecision(9) << x3;
	                *root = x3;
                    *count = iteration;
                    *flag = true;
	                break;
	            }
	            cout<<"Iteration: " << iteration<< " and the root estimated is: " << setprecision(9) << x3 <<"\n";
	            error = abs((x4 - x3)/x3);
	        }else{
	            if(error < threshold){
	                cout<<"Iteration: " << iteration << " and the root estimated is: " << setprecision(9) << x3;
	                *root = x3;
                    *count = iteration;
                    *flag = true;
                    break;
	            }
	            cout<<"Iteration: " << iteration<< " and the root estimated is: " << setprecision(9) << x3 <<"\n";
	            error = abs(f(x3));
	        }
	    }
    }
}

int main(){
    int userChoice = -1;
    int x1value;
    int x2value;
    double threshold;
    double root;
    int iteration;
    bool flag = false;
    
	cout<< "Choose one of the following options to start the bisection program with the given function:";
	cout<< "\n 1. Abs Approx. Error \n 2. Abs. Relative Approx. Error \n 3. True Abs. Error \n";
	cin >> userChoice;
	while((userChoice != 1) && (userChoice != 2) && (userChoice != 3)){
	    cout<<"Please enter an option from 1 - 3: \n";
	    cin >> userChoice;
	}
	cout<<"Please enter the value of x1: "; cin >> x1value; cout<<endl;
	cout<<"Please enter the value of x2: "; cin >> x2value; cout<<endl;
	cout<<"Please enter the value of the pre-determined threshold: "; cin >> threshold; cout<<endl;
	bisection (x1value,x2value,threshold,userChoice, &root, &iteration, &flag);
	cout<<endl;
	
	if (flag == true){
	    cout<<"After " << iteration << " iterations, the final value of the root is: " << root;
	}
}
