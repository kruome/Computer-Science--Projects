<h3>The choice of brackets is justfied through the method of graphing. After graphing the equation and then taking a look at the possible roots in the interval [-1,3], I was able to find 3 different roots within. Thus, after choosing specific points that surround each root without coming into conflict with one another, I was able to choose appropriate brackets.
</h3>
