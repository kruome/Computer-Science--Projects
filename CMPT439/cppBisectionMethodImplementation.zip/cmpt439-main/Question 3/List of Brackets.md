<h3>First Bracket: [-1 , 0] </h3>

<h3>Second Bracket: [0 , 1] </h3>

<h3>Third Bracket: [2, 3]</h3>
