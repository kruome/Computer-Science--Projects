<h3>In conclusion, there are both equivalence and better stopping criterion for the program. 
For all runs to find the root through the 3 distinct error stopping criterion, the two that were more or less
equal were the absolute approximation error and the true absolute error since it took the two errors roughly the same number of iterations 
to stop the program from finding more root values. However, the absolute relative approximation error falls
short when compared to the two aforementioned since it takes longer, in this case an interation mroe, to display
the root value.</h3>
