<h1 align = "center"> Technical Report for Question 2</h1>

<h3 align = "center">Interval [-7, -5]</h3>

|                                       | Iteration | Root        |
|:---------------------------------------:|:-----------:|-------------|
| Absolute Approximation Error          | 21        | -5.75913095 |
| Absolute Relative Approximation Error | 19        | -5.75913048 |
| True Absolute Error                   | 21        | -5.75913095 |

<h3 align = "center">Interval [-5, -3]</h3>

|                                       | Iteration | Root        |
|---------------------------------------|-----------|-------------|
| Absolute Approximation Error          | 21        | -3.66887712 |
| Absolute Relative Approximation Error | 20        |  -3.6688776 |
| True Absolute Error                   | 18        | -3.66888046 |
