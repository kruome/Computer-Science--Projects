<h1 align = "center"> Technical Report for Question 3</h1>

<h3 align = "center">Bracket one: [-1, 0]</h3>

|                              | Iteration | Root         |
|------------------------------|-----------|--------------|
| Absolute Approximation Error | 20        | -0.314158916 |

<h3 align = "center">Bracket two: [0, 1]</h3>

|                                       | Iteration | Root        |
|---------------------------------------|-----------|-------------|
| Absolute Relative Approximation Error | 21        | 0.942477942 |

<h3 align = "center">Bracket three: [2, 3]</h3>

|                     | Iteration | Root       |
|---------------------|-----------|------------|
| True Absolute Error | 20        | 2.19911528 |
